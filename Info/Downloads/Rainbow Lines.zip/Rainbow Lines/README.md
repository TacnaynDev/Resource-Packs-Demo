# Rainbow Lines
https://raw.githubusercontent.com/TacnaynDev/Resource-Packs-Demo/main/img/rainbow_lines_loop.gif
Settings can be found in assets/minecraft/shaders/include/config.glsl