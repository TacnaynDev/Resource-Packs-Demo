# Rainbow Tooltips
![Minecraft Item with Rainbow Background](https://raw.githubusercontent.com/TacnaynDev/Resource-Packs-Demo/main/img/rainbow_tooltips_thumb.gif)  
[Download Here](https://github.com/TacnaynDev/Resource-Packs-Demo/blob/main/Info/Downloads/Rainbow%20Tooltips.zip)  
Settings can be found in assets/minecraft/shaders/include/config.glsl